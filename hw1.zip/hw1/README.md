Joseph Muffoletto
jrm7925
CS 395T, Prof. Topcu
HW1, Exercise 4

Exercise 4 files:
    Part A:
        Lab1E4.smv - implementation of figure 4 using NuSMV
        sample_traces.txt - sample paths generated using the NuSMV simulator and the FTS in Lab1E4.smv
    Part B:
        FTS.py - python implementation of an FTS and a path generator